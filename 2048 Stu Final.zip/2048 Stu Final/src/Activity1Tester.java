
public class Activity1Tester {

	public static void main(String[] args) {
		
		// Create a Board object
		Board b = new Board();
		
		// invoke the toString method by passing the object to 
		// print or println
		
		
		
		//String str = String.format("%04d", 9);  // 0009      
		//System.out.println(str);
		
		System.out.println(b);
	}

}
