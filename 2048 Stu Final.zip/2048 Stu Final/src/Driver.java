
public class Driver {
	public static void main(String[] arg) {
	
		int[][] data = { {2,2,0,2},  
						 {2,2,2,2}, 
						 {128,128,64,32}, 
						 {4,4,2,2}
						};
		BoardGUI b = new BoardGUI();
		
	}
}
