import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.geom.AffineTransform;
import java.net.URL;

/* class to represent a Frog object in a game of Car */
public class Car {

	//attributed of a Frog
	private int x, y; //position of Car
	private boolean alive;
	private int width, height;
	private Image img;
	private int vx, vy; //velocity of Car
	private AffineTransform tx = AffineTransform.getTranslateInstance(x, y);
	
	//write the constructor for Car which takes in 
	//a string fileName that will be used for image setup
	//set x and y to be in the middle of a 400x400 screen
	//set width and height to 50
	public Car(String fileName, int newx, int newy, int newvx){
		x = newx;
		y = newy;
		width = 80;
		height = 50;
		img = getImage(fileName);
		init(x,y);
		vx = newvx;
	}
	public void setVx(int newVx){
		if (vy == 0){
		vx = newVx;
		}
	}
	public void setVy(int newVy){
		if (vx == 0){
		vy = newVy;
		}
	}
	
	public int getX(){
		return x;
	}
	public int getY(){
		return y;
	}
	public int getWidth(){
		return width;
	}
	public int getHeight(){
		return height;
	}
	
	
	
	
	
	public void move() {
		tx.translate(vx, vy);
		x+=vx;
		y+=vy;
		
		//change based on direction of vx
		//teleports Car back to other side of screen after it goes off-screen
		if(x<0){
			x=900;
			tx.setToTranslation(x,y);
		}
		if(x>900){
			x=0;
			tx.setToTranslation(x,y);
		}
	}

	//draw the affinetransform
		public void paint(Graphics g) {
			Graphics2D g2 = (Graphics2D) g;
			g2.drawImage(img, tx, null);
		}

		private void init(double a, double b) {
			tx.setToTranslation(a, b);
			tx.scale(1,1);
		}

		// converts image to make it drawable in paint
		private Image getImage(String path) {
			Image tempImage = null;
			try {
				URL imageURL = Froggy.class.getResource(path);
				tempImage = Toolkit.getDefaultToolkit().getImage(imageURL);
			} catch (Exception e) {
				e.printStackTrace();
			}
			return tempImage;
		}


}



