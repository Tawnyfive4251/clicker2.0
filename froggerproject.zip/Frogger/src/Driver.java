/*
 * Comments below
 * The movement of the 'logs' which are trucks are a little wack
 * nice movement of the frog and nice level of difficulty
 * 
 * i didnt know that the trucks were logs
 * sort of difficult to know whats what
 * Thats pretty epic. First won i one.
 * Cool game
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 */




import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.Vector;
import java.util.concurrent.TimeUnit;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;

import java.awt.image.*;
import java.awt.geom.AffineTransform;

public class Driver extends JPanel implements ActionListener, KeyListener,
		MouseListener, MouseMotionListener {
	
	int lives = 10;
	int score;
	boolean lose = false;
	boolean win = false;
	boolean restart = false;
	public boolean on;
	public boolean on1;
	boolean water;
	int screen_width = 900;
	int screen_height = 900;
	Froggy froggy;
	Background background = new Background();
	Car[] carList = new Car[5];
	Car[] carList1 = new Car[5];
	Car[] carList2 = new Car[5];
	Car[] carList3 = new Car[5];
	
	Truck[] truckList = new Truck[5];
	Truck[] truckList1 = new Truck[5];

	//Background bg;
	int my_variable = 0; //example
	
	
	String lost = "";
	
	public void paint(Graphics g) {
		
		super.paintComponent(g);
		//bg.paint(g);
		
		
		g.setFont(font);
		g.setColor(Color.RED);
		g.drawString(("my_variable:")+Integer.toString(my_variable), 0, 870);
		g.setFont(font2);
		g.setColor(Color.CYAN);
	
		//paint sprite 
		
		background.paint(g);

		
		
	
		
		for (int i = 0; i<carList.length; i++){
			carList[i].paint(g);
			carList1[i].paint(g);
			carList2[i].paint(g);
			carList3[i].paint(g);
		}
		
		for (int i = 0; i<truckList.length; i++){
			truckList[i].paint(g);
			truckList1[i].paint(g);
			//g.fillRect((int)truckList[1].getX()-400,(int)truckList[1].getY()+25,300,100);
			//g.fillRect((int)truckList1[1].getX()-400,(int)truckList1[1].getY()+25,300,100);

		}
		
		
		
		
		
		g.setColor(Color.BLACK);
		//g.fillRect(froggy.getX(), froggy.getY(), froggy.getWidth(), froggy.getHeight());
		froggy.paint(g);	
		
		
		g.setColor(Color.BLACK);
		g.drawString("LIVES: "+lives,0,865);
		g.drawString("SCORE: "+score,200,865);
		
		if(lose == true){
			g.fillRect(0,0,900,900);
			g.setColor(Color.PINK);
			g.drawString("You Lost",400,400);
			g.drawString("Play again?(press enter)",400,500);

		}
		if(win == true){
			g.fillRect(0,0,900,900);
			g.setColor(Color.GREEN);
			g.drawString("You Won",400,400);
			g.drawString("Play again?(press enter)",400,500);
		}
		if(restart == true){
			win = false;
			lose = false;
			score = 0;
			lives = 10;
			froggy.setX(450);
			froggy.setY(830);
		}
		
	}
	
	
	Font font = new Font("Courier New", 1, 50);
	Font font2 = new Font("Courier New", 1, 30);
	public void update() {
		
		
		
		for(int i = 0; i < carList.length; i++){
			carList[i].move();
			carList1[i].move();
			carList2[i].move();
			carList3[i].move();
			
			
			if(froggy.getY()==70){
				score++;
				froggy.setX(450);
				froggy.setY(830);
			}
			
			if(score>=5){
				win = true;
			}
			
			
			if(froggy.collided((int)truckList[1].getX()-400,(int)truckList[1].getY()+25,300,100)){
				if(lives>0){
					lives-=1;
				} else {
					lose = true;
				}
			}
			
			if(froggy.collided((int)truckList1[1].getX()-400,(int)truckList1[1].getY()+25,300,100)){
				if(lives>0){
					lives-=1;
				} else {
					lose = true;
				}
			}
			
			if(froggy.collided(carList[i].getX()+30, carList[i].getY()+50, carList[i].getWidth(), carList[i].getHeight())){
				if(lives>0){
				lives -= 1;
				froggy.setX(450);
				froggy.setY(830);
				} else {
				lose = true;
				
				}
				
				}
		
			if(froggy.collided(carList1[i].getX()+30, carList1[i].getY()+50, carList1[i].getWidth(), carList1[i].getHeight())){
				lives -= 1;
				froggy.setX(450);
				froggy.setY(830);
				if(lives < 0){
					lose = true;
				}
				
				}
			if(froggy.collided(carList2[i].getX()+30, carList2[i].getY()+50, carList2[i].getWidth(), carList2[i].getHeight())){
				lives -= 1;
				froggy.setX(450);
				froggy.setY(830);
				if(lives < 0){
					lose = true;
				}
				
				}
			if(froggy.collided(carList3[i].getX()+30, carList3[i].getY()+50, carList3[i].getWidth(), carList3[i].getHeight())){
				lives -= 1;
				froggy.setX(450);
				froggy.setY(830);
				if(lives < 0){
					lose = true;
				}
				
				}
			
		
			
		
		for(int j = 0; j < truckList.length; j++){
			truckList[j].move();
			truckList1[j].move();
	
			

			
			if(froggy.collided((int)(truckList[j].getX()), (int)(truckList[j].getY())+50, truckList[j].getWidth(), truckList[j].getHeight())){
				froggy.setVx(3);
			//} 	else {
			//	on = false;
			}
			if(froggy.collided((int)(truckList1[j].getX()), (int)(truckList1[j].getY())+50, truckList1[j].getWidth(), truckList1[j].getHeight())){
				froggy.setVx(-3);

			//} else {
			//	on1 = false;
			}
		
		}
		
		
		
		
		/*
		System.out.println(froggy.getX());
		System.out.println(froggy.getY());
		System.out.println(froggy.getWidth());
		System.out.println(froggy.getHeight());
		

		System.out.println("x:"+carList[0].getX());
		System.out.println("y:"+carList[0].getY());
		System.out.println("width:"+ carList[0].getWidth());
		System.out.println("height:"+carList[0].getHeight());
		
		System.out.println("truck speed:"+truckList[0].getVx());
		*/
		}
		
}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		update();
		repaint();
		froggy.move();
		
		
		
		
		
		
		
		if(on == true){
			froggy.setVx(3);
		}
		if(on1 == true){
			froggy.setVx(-3);
		}
	}

	public static void main(String[] arg) {
		Driver d = new Driver();
	}
	
	
	
	

	public Driver() {
		JFrame f = new JFrame();
		f.setTitle("Frogger");
		f.setSize(screen_width, screen_height);
		f.setResizable(false);
		f.addKeyListener(this);
		f.addMouseListener(this);
		
		//sprite instantiation
		froggy = new Froggy("froggy.png");
		for (int i = 0; i<carList.length; i++){
			carList[i] = new Car ("carright.png",(i*100),675,3);
			carList1[i] = new Car ("carright.png",(i*100),510,2);
			carList2[i] = new Car ("carleft.png",(i*100),600,-3);
			carList3[i] = new Car ("carleft.png",(i*100),390,-2);

		}
		for (int k = 0; k<carList.length; k++){
			truckList[k] = new Truck ("truckright.png",k*125,80,0.6);
			truckList1[k] = new Truck ("truckleft.png",(k*125),190,-0.6);

		}
		
		//player.addMouseListener(this);
		//bg = new Background("background.png");
		//do not add to frame, call paint on
		//these objects in paint method
		
		
		f.add(this);
		t = new Timer(17, this);
		t.start();
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setVisible(true);
		
		
		
		
		
	}
	
	Timer t;

	@Override
	public void keyPressed(KeyEvent e) {
		if(e.getKeyCode()==38){
			froggy.setVy(-20);
			restart = false;
		} 
		if(e.getKeyCode()==40){
			froggy.setVy(20);
			restart = false;

			
		} 
		if(e.getKeyCode()==39){
			froggy.setVx(20);
			restart = false;

			
		} 
		if(e.getKeyCode()==37){
			froggy.setVx(-20);
			restart = false;

			
		} 
		if(e.getKeyCode()==10){
			restart = true;
			
		}
	}
	
	@Override
	public void keyReleased(KeyEvent e) {
		//stem.out.println(e.getKeyCode());
		if(e.getKeyCode()==38){
			froggy.setVy(0);
		}
		if(e.getKeyCode()==40){
			froggy.setVy(0);
		} 
		if(e.getKeyCode()==39){
			froggy.setVx(0);
		} 
		if(e.getKeyCode()==37){
			froggy.setVx(0);
		} 
		
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseClicked(MouseEvent e) {
		
	
	}

	@Override
	public void mouseEntered(MouseEvent e) {

	}

	@Override
	public void mouseExited(MouseEvent e) {

	}

	public void reset() {

	}

	@Override
	public void mousePressed(MouseEvent e) {

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseDragged(MouseEvent e) {

	}

	@Override
	public void mouseMoved(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

}
