import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.geom.AffineTransform;
import java.net.URL;

/* class to represent a Frog object in a game of Frogger */
public class Froggy {

	//attributed of a Frog
	private int x, y; //position of Froggy
	private boolean alive;
	private int width, height;
	private Image img;
	private int vx, vy; //velocity of froggy
	private AffineTransform tx = AffineTransform.getTranslateInstance(x, y);
	
	//write the constructor for froggy which takes in 
	//a string fileName that will be used for image setup
	//set x and y to be in the middle of a 400x400 screen
	//set width and height to 50
	public Froggy(String fileName){
		x = 450;
		y = 830;
		width = 50;
		height = 50;
		alive = true;	
		img = getImage(fileName);
		init(x,y);
	}
	public void setVx(int newVx){
			vx = newVx;
			
	}
	public void setVy(int newVy){
		vy = newVy;
	
	}
	public int getVx(){
		return vx;
	}
	
	public boolean collided(int ox, int oy, int ow, int oh){
		
		Rectangle obs = new Rectangle(ox, oy, ow, oh); // from parameters
		Rectangle froggy = new Rectangle(x,y,width,height); // from attributes
		
		return obs.intersects(froggy);
		
	}
	public void setX(int newX){
		x = newX;
		tx.setToTranslation(x, y); // update after getting current x

	}
	public void setY(int newY){
		y = newY;
		tx.setToTranslation(x, y); // update after getting current y

	}
	
	public int getX(){
		return x;
	}
	
	public int getY(){
		return y;
	}
	
	
	public int getWidth(){
		return width;
	}
	public int getHeight(){
		return height;
	}
	
	
	
	
	public void move() {
		x+=vx;
		y+=vy;
		tx.translate(vx, vy);
	}

	//draw the affinetransform
		public void paint(Graphics g) {
			Graphics2D g2 = (Graphics2D) g;
			g2.drawImage(img, tx, null);
		}

		private void init(double a, double b) {
			tx.setToTranslation(a, b);
			tx.scale(1,1);
		}

		// converts image to make it drawable in paint
		private Image getImage(String path) {
			Image tempImage = null;
			try {
				URL imageURL = Froggy.class.getResource(path);
				tempImage = Toolkit.getDefaultToolkit().getImage(imageURL);
			} catch (Exception e) {
				e.printStackTrace();
			}
			return tempImage;
		}


}


